<?php
session_start();
require '../config/session_config.php';

$user = get_tab_session();
if (!$user || ($user['role'] ?? '') !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

require '../config/koneksi.php';

$aksi = $_POST['aksi'];

if ($aksi == 'tambah') {
    $id_produk = mysqli_real_escape_string($koneksi, $_POST['id_produk']);
    $jenis_diskon = mysqli_real_escape_string($koneksi, $_POST['jenis_diskon']);
    $diskon_persen = ($jenis_diskon == 'persen') ? mysqli_real_escape_string($koneksi, $_POST['diskon_persen']) : NULL;
    $diskon_nominal = ($jenis_diskon == 'nominal') ? mysqli_real_escape_string($koneksi, $_POST['diskon_nominal']) : NULL;
    $tanggal_mulai = mysqli_real_escape_string($koneksi, $_POST['tanggal_mulai']);
    $tanggal_akhir = mysqli_real_escape_string($koneksi, $_POST['tanggal_akhir']);
    $status = mysqli_real_escape_string($koneksi, $_POST['status']);

    // Cek apakah produk sudah memiliki promo aktif yang overlap dengan tanggal baru
    $check_q = "SELECT COUNT(*) AS cnt FROM promo WHERE id_produk = '$id_produk' AND status = 'aktif' AND NOT (tanggal_akhir < '$tanggal_mulai' OR tanggal_mulai > '$tanggal_akhir')";
    $check_r = mysqli_query($koneksi, $check_q);
    $check_row = mysqli_fetch_assoc($check_r);
    if ($check_row && $check_row['cnt'] > 0) {
        header("Location: ../admin/master_promo.php?pesan=duplikat");
        exit;
    }

    $query = "INSERT INTO promo (id_produk, diskon_persen, diskon_nominal, tanggal_mulai, tanggal_akhir, status)
              VALUES ('$id_produk', " . ($diskon_persen ? "'$diskon_persen'" : "NULL") . ", " . ($diskon_nominal ? "'$diskon_nominal'" : "NULL") . ", '$tanggal_mulai', '$tanggal_akhir', '$status')";

    if (mysqli_query($koneksi, $query)) {
        header("Location: ../admin/master_promo.php?pesan=sukses");
    } else {
        header("Location: ../admin/master_promo.php?pesan=gagal");
    }
} elseif ($aksi == 'edit') {
    $id_promo = mysqli_real_escape_string($koneksi, $_POST['id_promo']);
    $id_produk = mysqli_real_escape_string($koneksi, $_POST['id_produk']);
    $jenis_diskon = mysqli_real_escape_string($koneksi, $_POST['jenis_diskon']);
    $diskon_persen = ($jenis_diskon == 'persen') ? mysqli_real_escape_string($koneksi, $_POST['diskon_persen']) : NULL;
    $diskon_nominal = ($jenis_diskon == 'nominal') ? mysqli_real_escape_string($koneksi, $_POST['diskon_nominal']) : NULL;
    $tanggal_mulai = mysqli_real_escape_string($koneksi, $_POST['tanggal_mulai']);
    $tanggal_akhir = mysqli_real_escape_string($koneksi, $_POST['tanggal_akhir']);
    $status = mysqli_real_escape_string($koneksi, $_POST['status']);

    // Cek overlap promo aktif pada produk yang sama (kecuali promo yang sedang diedit)
    $check_q = "SELECT COUNT(*) AS cnt FROM promo WHERE id_produk = '$id_produk' AND status = 'aktif' AND id_promo != '$id_promo' AND NOT (tanggal_akhir < '$tanggal_mulai' OR tanggal_mulai > '$tanggal_akhir')";
    $check_r = mysqli_query($koneksi, $check_q);
    $check_row = mysqli_fetch_assoc($check_r);
    if ($check_row && $check_row['cnt'] > 0) {
        header("Location: ../admin/master_promo.php?pesan=duplikat");
        exit;
    }

    $query = "UPDATE promo SET
                id_produk = '$id_produk',
                diskon_persen = " . ($diskon_persen ? "'$diskon_persen'" : "NULL") . ",
                diskon_nominal = " . ($diskon_nominal ? "'$diskon_nominal'" : "NULL") . ",
                tanggal_mulai = '$tanggal_mulai',
                tanggal_akhir = '$tanggal_akhir',
                status = '$status'
              WHERE id_promo = '$id_promo'";

    if (mysqli_query($koneksi, $query)) {
        header("Location: ../admin/master_promo.php?pesan=sukses");
    } else {
        header("Location: ../admin/master_promo.php?pesan=gagal");
    }
} elseif ($aksi == 'hapus') {
    $id_promo = $_POST['id_promo'];

    $query = "DELETE FROM promo WHERE id_promo = '$id_promo'";

    if (mysqli_query($koneksi, $query)) {
        header("Location: ../admin/master_promo.php?pesan=sukses");
    } else {
        header("Location: ../admin/master_promo.php?pesan=gagal");
    }
} else {
    header("Location: ../admin/master_promo.php");
}
